// Entendiendo por una pass compleja:
	// 8+ caracteres
	// una mayuscula
	// una letra
	// un numero
$.validator.addMethod("pass", function(value, element) {
	var passw = $("#password").val();   
	if (passw.length > 7 && (passw.match(/[A-z]/) && passw.match(/[A-Z]/) 
		&& passw.match(/[0-9]/))) {
		return true;
	}
	return false;
}, "Contraseña incorrecta, debe ser una contraseña segura."); 
